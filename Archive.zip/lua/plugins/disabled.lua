return {
  { "rcarriga/nvim-notify", enabled = false },
  { "akinsho/bufferline.nvim", enabled = false },
  { "ThePrimeagen/vim-be-good", enabled = false },
  { "nvim-neo-tree/neo-tree.nvim", enabled = false },
  { "nvim-neo-tree/neotree.nvim", enabled = false },
  { "echasnovski/mini.sessions", enabled = false },
  { "nvim-lualine/lualine.nvim", enabled = false },
}
